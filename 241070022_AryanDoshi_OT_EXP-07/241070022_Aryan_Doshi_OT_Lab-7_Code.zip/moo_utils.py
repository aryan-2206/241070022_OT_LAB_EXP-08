"""
moo_utils.py -- shared toolkit for Lab Assignment 7 (Task A1).
All objectives are MINIMISED. Maximisation problems are converted with Max f = Min -f.

Contents
  dominates, constrained_dominates (Deb's three rules), dominance_matrix
  non_dominated_mask, fast_non_dominated_sort, crowding_distance
  normalize, das_dennis
  hypervolume_2d (exact), hypervolume (2-D exact, >=3-D Monte Carlo), igd, spacing
  run_unit_tests()  -> hand-checkable tests on small cases
Only NumPy is used.
"""
import numpy as np


# ----------------------------------------------------------------------------
# Dominance
# ----------------------------------------------------------------------------
def dominates(a, b):
    """True if a Pareto-dominates b (a<=b everywhere and a<b somewhere)."""
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    return bool(np.all(a <= b) and np.any(a < b))


def constrained_dominates(fa, cva, fb, cvb):
    """Deb's three feasibility rules.
    1) feasible beats infeasible; 2) two infeasible: smaller violation wins;
    3) two feasible: ordinary Pareto dominance."""
    a_ok, b_ok = cva <= 0, cvb <= 0
    if a_ok and not b_ok:
        return True
    if (not a_ok) and b_ok:
        return False
    if (not a_ok) and (not b_ok):
        return bool(cva < cvb)
    return dominates(fa, fb)


def dominance_matrix(F, CV=None):
    """D[i, j] == True  <=>  i dominates j (constrained dominance if CV given)."""
    F = np.asarray(F, float)
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    D = le & lt
    if CV is not None:
        CV = np.asarray(CV, float)
        feas = CV <= 0
        both_feas = feas[:, None] & feas[None, :]
        both_inf = (~feas[:, None]) & (~feas[None, :])
        D = np.where(both_feas, D, False)
        D = D | (feas[:, None] & ~feas[None, :])
        D = D | (both_inf & (CV[:, None] < CV[None, :]))
    return D


def non_dominated_mask(F, CV=None):
    """Boolean mask of the non-dominated rows of F."""
    F = np.asarray(F, float)
    if len(F) == 0:
        return np.zeros(0, bool)
    return ~dominance_matrix(F, CV).any(axis=0)


def fast_non_dominated_sort(F, CV=None):
    """Deb's fast non-dominated sorting. Returns (list_of_fronts, rank_array)."""
    F = np.asarray(F, float)
    n = len(F)
    D = dominance_matrix(F, CV)
    cnt = D.sum(axis=0).astype(int)          # how many solutions dominate j
    rank = np.full(n, -1, int)
    fronts = []
    cur = np.where(cnt == 0)[0]
    r = 0
    while len(cur) > 0:
        rank[cur] = r
        fronts.append(cur)
        cnt = cnt - D[cur].sum(axis=0)
        cnt[rank >= 0] = -1                  # already placed
        cur = np.where(cnt == 0)[0]
        r += 1
    return fronts, rank


def crowding_distance(F):
    """NSGA-II crowding distance of the rows of F (one front)."""
    F = np.asarray(F, float)
    n, m = F.shape
    d = np.zeros(n)
    if n <= 2:
        d[:] = np.inf
        return d
    for j in range(m):
        idx = np.argsort(F[:, j], kind="stable")
        lo, hi = F[idx[0], j], F[idx[-1], j]
        d[idx[0]] = d[idx[-1]] = np.inf
        if hi - lo <= 0:
            continue
        d[idx[1:-1]] += (F[idx[2:], j] - F[idx[:-2], j]) / (hi - lo)
    return d


# ----------------------------------------------------------------------------
# Normalisation and reference vectors
# ----------------------------------------------------------------------------
def normalize(F, ideal=None, nadir=None):
    """Map objectives to ~[0,1]:  (f - ideal) / (nadir - ideal)."""
    F = np.asarray(F, float)
    ideal = F.min(axis=0) if ideal is None else np.asarray(ideal, float)
    nadir = F.max(axis=0) if nadir is None else np.asarray(nadir, float)
    span = np.where(nadir - ideal > 1e-12, nadir - ideal, 1.0)
    return (F - ideal) / span


def das_dennis(M, p):
    """Das-Dennis simplex-lattice reference points (rows sum to 1)."""
    from itertools import combinations
    pts = []
    for c in combinations(range(p + M - 1), M - 1):
        c = (-1,) + c + (p + M - 1,)
        pts.append([c[i + 1] - c[i] - 1 for i in range(M)])
    return np.array(pts, float) / p


# ----------------------------------------------------------------------------
# Quality indicators
# ----------------------------------------------------------------------------
def hypervolume_2d(F, ref):
    """Exact 2-D hypervolume (area dominated by F, bounded by ref)."""
    F = np.asarray(F, float)
    ref = np.asarray(ref, float)
    F = F[np.all(F < ref, axis=1)]
    if len(F) == 0:
        return 0.0
    F = F[np.argsort(F[:, 0], kind="stable")]
    hv, best2 = 0.0, ref[1]
    for f1, f2 in F:
        if f2 < best2:
            hv += (ref[0] - f1) * (best2 - f2)
            best2 = f2
    return float(hv)


def hypervolume(F, ref, n_samples=40000, seed=0):
    """2-D: exact sweep.  >=3-D: Monte-Carlo estimate in the box [min F, ref]."""
    F = np.asarray(F, float)
    ref = np.asarray(ref, float)
    F = F[np.all(F < ref, axis=1)]
    if len(F) == 0:
        return 0.0
    if F.shape[1] == 2:
        return hypervolume_2d(F, ref)
    lo = F.min(axis=0)
    rng = np.random.default_rng(seed)
    S = lo + rng.random((n_samples, len(ref))) * (ref - lo)
    hit = 0
    for i in range(0, n_samples, 2000):
        s = S[i:i + 2000]
        hit += (F[None, :, :] <= s[:, None, :]).all(axis=2).any(axis=1).sum()
    return float(hit / n_samples * np.prod(ref - lo))


def igd(F, Z):
    """Inverted generational distance: mean distance from each true-front point Z
    to its nearest obtained point in F.  Smaller is better."""
    F = np.asarray(F, float)
    Z = np.asarray(Z, float)
    if len(F) == 0:
        return np.inf
    d = np.sqrt(((Z[:, None, :] - F[None, :, :]) ** 2).sum(axis=2))
    return float(d.min(axis=1).mean())


def spacing(F):
    """Schott-type spacing: std of nearest-neighbour distances along the front."""
    F = np.asarray(F, float)
    n = len(F)
    if n < 3:
        return 0.0
    d = np.sqrt(((F[:, None, :] - F[None, :, :]) ** 2).sum(axis=2))
    np.fill_diagonal(d, np.inf)
    nn = d.min(axis=1)
    return float(nn.std(ddof=1))


# ----------------------------------------------------------------------------
# Unit tests (answers can be checked by hand)
# ----------------------------------------------------------------------------
def run_unit_tests(verbose=True):
    out = []

    def check(name, cond):
        assert cond, "FAILED: " + name
        out.append(name)

    # Dominance
    check("dominates basic", dominates([1, 2], [2, 3]) and not dominates([1, 3], [2, 2]))
    check("equal vectors do not dominate", not dominates([1, 1], [1, 1]))

    # Car example (price in k$, 0-100 km/h seconds; both minimised)
    cars = np.array([[20, 10], [25, 8], [30, 6], [28, 9], [35, 5.5], [40, 6]])
    mask = non_dominated_mask(cars)
    check("car example Pareto set = cars A,B,C,E", list(np.where(mask)[0]) == [0, 1, 2, 4])
    fronts, rank = fast_non_dominated_sort(cars)
    check("car example fronts", list(rank) == [0, 0, 0, 1, 0, 1])

    # Deb's constrained dominance (rules checked one by one)
    F = np.array([[1, 5], [2, 2], [3, 1], [0.5, 0.5], [0.1, 0.1]])
    CV = np.array([0, 0, 0, 2.0, 0.5])
    check("rule1 feasible beats infeasible", constrained_dominates(F[0], 0, F[3], 2.0))
    check("rule2 smaller violation wins", constrained_dominates(F[4], 0.5, F[3], 2.0))
    check("rule3 Pareto for feasible pair", not constrained_dominates(F[0], 0, F[1], 0)
          and not constrained_dominates(F[1], 0, F[0], 0))
    fronts, rank = fast_non_dominated_sort(F, CV)
    check("constrained sort ranks", list(rank) == [0, 0, 0, 2, 1] or list(rank) == [0, 0, 0, 2, 1])

    # Crowding distance, three points on a line
    cd = crowding_distance(np.array([[0, 4], [1, 3], [4, 0]], float))
    check("crowding boundary inf", np.isinf(cd[0]) and np.isinf(cd[2]))
    check("crowding middle = 4/4+4/4 = 2", abs(cd[1] - 2.0) < 1e-12)

    # Hypervolume 2-D hand value: points (1,3),(2,2),(3,1) ref (4,4) -> 6
    check("HV2D = 6", abs(hypervolume_2d(np.array([[1, 3], [2, 2], [3, 1]]), [4, 4]) - 6.0) < 1e-12)
    # 3-D Monte Carlo sanity: single point (0,0,0) ref (1,1,1) -> 1
    check("HV3D single point ~ 1", abs(hypervolume(np.zeros((1, 3)), [1, 1, 1]) - 1.0) < 1e-9)
    check("HV3D two boxes ~ 0.75 (inclusion-exclusion)",
          abs(hypervolume(np.array([[0, 0.5, 0], [0.5, 0, 0]]), [1, 1, 1], 200000) - 0.75) < 0.02)

    # IGD / Spacing
    check("IGD zero for identical sets", igd(np.array([[0, 1], [1, 0]]), np.array([[0, 1], [1, 0]])) == 0)
    check("IGD = 1 when F is one point 1 away", abs(igd(np.array([[0.0, 0.0]]), np.array([[1.0, 0.0]])) - 1.0) < 1e-12)
    check("spacing zero for equally spaced", spacing(np.array([[0, 3], [1, 2], [2, 1], [3, 0]], float)) < 1e-12)
    check("normalize", np.allclose(normalize(np.array([[0, 10], [2, 20]])), [[0, 0], [1, 1]]))
    check("das_dennis count C(p+M-1,M-1)", len(das_dennis(3, 4)) == 15 and abs(das_dennis(3, 4).sum(1) - 1).max() < 1e-12)
    if verbose:
        print("moo_utils unit tests passed (%d checks)" % len(out))
    return True


if __name__ == "__main__":
    run_unit_tests()
