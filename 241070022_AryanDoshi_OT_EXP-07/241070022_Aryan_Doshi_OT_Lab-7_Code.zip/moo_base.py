"""
moo_base.py -- small framework shared by all 37 algorithm modules.
  * variation operators (SBX, polynomial mutation, order crossover, swap/inversion, DE)
  * Archive (bounded non-dominated archive) and grid helpers
  * MOAlgorithm: base class with initialize / evaluate / iterate / run
Everything is written from scratch with NumPy.
"""
import time
import numpy as np
from moo_utils import (non_dominated_mask, crowding_distance, fast_non_dominated_sort,
                       dominance_matrix, normalize)


class BudgetExhausted(Exception):
    """Raised by MOAlgorithm.evaluate when the evaluation budget would be exceeded."""


# ----------------------------------------------------------------------------
# Variation operators
# ----------------------------------------------------------------------------
def sbx(P1, P2, lb, ub, rng, eta=15.0, pc=0.9):
    """Simulated binary crossover (bounded by clipping)."""
    n, d = P1.shape
    u = rng.random((n, d))
    beta = np.where(u <= 0.5, (2 * u) ** (1 / (eta + 1)), (1 / (2 * (1 - u + 1e-12))) ** (1 / (eta + 1)))
    c1 = 0.5 * ((1 + beta) * P1 + (1 - beta) * P2)
    c2 = 0.5 * ((1 - beta) * P1 + (1 + beta) * P2)
    swap = rng.random((n, d)) < 0.5
    c1, c2 = np.where(swap, c2, c1), np.where(swap, c1, c2)
    do = rng.random((n, 1)) < pc
    c1, c2 = np.where(do, c1, P1), np.where(do, c2, P2)
    return np.clip(c1, lb, ub), np.clip(c2, lb, ub)


def poly_mut(X, lb, ub, rng, eta=20.0, pm=None):
    """Polynomial mutation, probability pm per variable (default 1/n)."""
    n, d = X.shape
    pm = 1.0 / d if pm is None else pm
    mask = rng.random((n, d)) < pm
    u = rng.random((n, d))
    delta = np.where(u < 0.5, (2 * u) ** (1 / (eta + 1)) - 1, 1 - (2 * (1 - u)) ** (1 / (eta + 1)))
    return np.clip(X + mask * delta * (ub - lb), lb, ub)


def order_crossover(p1, p2, rng):
    """OX: copy a slice of p1, fill the rest in the order of p2."""
    n = len(p1)
    a, b = np.sort(rng.choice(n, 2, replace=False))
    child = -np.ones(n, int)
    child[a:b + 1] = p1[a:b + 1]
    used = set(child[a:b + 1].tolist())
    rest = [g for g in p2 if g not in used]
    pos = [i for i in range(n) if child[i] < 0]
    child[pos] = rest
    return child


def perm_mutation(p, rng, pm=0.3):
    """Swap or inversion mutation of a permutation."""
    p = p.copy()
    if rng.random() < pm:
        a, b = np.sort(rng.choice(len(p), 2, replace=False))
        if rng.random() < 0.5:
            p[a], p[b] = p[b], p[a]                    # swap
        else:
            p[a:b + 1] = p[a:b + 1][::-1].copy()       # inversion
    return p


def vary(problem, P, rng, pc=0.9, eta_c=15.0, eta_m=20.0, pm=None):
    """Crossover + mutation of an even-sized parent array P (row 2k mates with row 2k+1)."""
    P = np.asarray(P)
    if len(P) % 2 == 1:
        P = np.vstack([P, P[:1]])
    if problem.vtype == "perm":
        out = []
        for i in range(0, len(P), 2):
            c1, c2 = (order_crossover(P[i], P[i + 1], rng), order_crossover(P[i + 1], P[i], rng)) \
                if rng.random() < pc else (P[i].copy(), P[i + 1].copy())
            out += [perm_mutation(c1, rng), perm_mutation(c2, rng)]
        return np.array(out)
    c1, c2 = sbx(P[0::2], P[1::2], problem.lb, problem.ub, rng, eta_c, pc)
    C = np.empty_like(P, dtype=float)
    C[0::2], C[1::2] = c1, c2
    return poly_mut(C, problem.lb, problem.ub, rng, eta_m, pm)


def neighbour(problem, x, rng, scale=0.05):
    """Small random move used by local search / simulated annealing."""
    x = np.array(x, copy=True)
    if problem.vtype == "perm":
        i, j = rng.choice(len(x), 2, replace=False)
        x[i], x[j] = x[j], x[i]
        return x
    if problem.vtype == "binary":
        k = rng.integers(len(x))
        x[k] = 1.0 - x[k]
        return x
    if problem.vtype == "int":
        k = rng.integers(len(x))
        x[k] += rng.choice([-1, 1])
        return x
    k = rng.random(len(x)) < max(1.0 / len(x), 0.3)
    return x + k * rng.normal(0, scale, len(x)) * (problem.ub - problem.lb)


def tournament_by_rank(rng, n, rank, crowd=None):
    """Binary tournament: lower rank wins, ties by larger crowding distance."""
    N = len(rank)
    a, b = rng.integers(0, N, n), rng.integers(0, N, n)
    better = rank[b] < rank[a]
    if crowd is not None:
        better |= (rank[b] == rank[a]) & (crowd[b] > crowd[a])
    else:
        better |= (rank[b] == rank[a]) & (rng.random(n) < 0.5)
    return np.where(better, b, a)


def tournament_by_fitness(rng, n, fit):
    """Binary tournament, larger fitness wins."""
    N = len(fit)
    a, b = rng.integers(0, N, n), rng.integers(0, N, n)
    return np.where(fit[b] > fit[a], b, a)


# ----------------------------------------------------------------------------
# Archive and grid
# ----------------------------------------------------------------------------
def grid_cells(F, ndiv=10):
    """Adaptive grid: integer cell id of each row of F."""
    lo, hi = F.min(axis=0), F.max(axis=0)
    span = np.where(hi - lo > 1e-12, hi - lo, 1.0)
    idx = np.minimum(((F - lo) / span * ndiv).astype(int), ndiv - 1)
    base = ndiv ** np.arange(F.shape[1])
    return (idx * base).sum(axis=1)


def grid_leader(F, rng, ndiv=10, power=1.0, k=1):
    """Pick k distinct leaders: roulette on cells with weight 1/count**power (less crowded first)."""
    cells = grid_cells(F, ndiv)
    uniq, inv, cnt = np.unique(cells, return_inverse=True, return_counts=True)
    chosen = []
    for _ in range(k):
        w = 1.0 / cnt.astype(float) ** power
        for c in chosen:
            w[inv[c]] = 0 if cnt[inv[c]] <= 1 else w[inv[c]]
        w = w / w.sum()
        cell = rng.choice(len(uniq), p=w)
        members = [i for i in np.where(inv == cell)[0] if i not in chosen]
        if not members:
            members = [i for i in range(len(F)) if i not in chosen] or [0]
        chosen.append(int(rng.choice(members)))
    return chosen


class Archive:
    """Bounded archive of feasible non-dominated solutions (constrained dominance)."""

    def __init__(self, capacity, mode="crowding", ndiv=10):
        self.capacity, self.mode, self.ndiv = capacity, mode, ndiv
        self.X = self.F = self.CV = None

    def __len__(self):
        return 0 if self.F is None else len(self.F)

    def add(self, X, F, CV, rng=None):
        if self.F is not None:
            X, F, CV = np.vstack([self.X, X]), np.vstack([self.F, F]), np.concatenate([self.CV, CV])
        keep = non_dominated_mask(F, CV)
        X, F, CV = X[keep], F[keep], CV[keep]
        _, uidx = np.unique(np.round(F, 10), axis=0, return_index=True)       # drop duplicates
        uidx = np.sort(uidx)
        X, F, CV = X[uidx], F[uidx], CV[uidx]
        while len(F) > self.capacity:
            if self.mode == "grid":
                cells = grid_cells(F, self.ndiv)
                u, cnt = np.unique(cells, return_counts=True)
                worst = u[np.argmax(cnt)]
                members = np.where(cells == worst)[0]
                rm = (rng or np.random.default_rng(0)).choice(members)
            else:
                cd = crowding_distance(F)
                cd[np.isinf(cd)] = np.inf
                rm = int(np.argmin(np.where(np.isinf(cd), 1e18, cd)))
            sel = np.arange(len(F)) != rm
            X, F, CV = X[sel], F[sel], CV[sel]
        self.X, self.F, self.CV = X, F, CV


# ----------------------------------------------------------------------------
# Base class
# ----------------------------------------------------------------------------
class MOAlgorithm:
    """initialize() -> evaluate() -> iterate() -> run().  Subclass and implement iterate()."""
    number, name, family = 0, "base", ""

    def __init__(self, problem, pop_size=100, seed=0, verbose=False, **params):
        self.problem, self.N, self.seed = problem, int(pop_size), seed
        self.rng = np.random.default_rng(seed)
        self.params = params
        self.verbose = verbose
        self.nfe, self.gen, self.budget = 0, 0, np.inf
        self.history, self.archive = [], None
        self.X = self.F = self.CV = None

    # -- helpers ------------------------------------------------------------
    def log(self, key, value):
        """Trace printing used for the hand-trace (Task C)."""
        if self.verbose:
            print("   %-22s %s" % (key, np.array2string(np.asarray(value), precision=4, suppress_small=True,
                                                          max_line_width=110).replace("\n", "\n" + " " * 26)))

    def evaluate(self, X):
        X = self.problem.repair(np.atleast_2d(X).copy())
        if self.nfe + len(X) > self.budget:
            raise BudgetExhausted()
        F, CV = self.problem.evaluate(X)
        self.nfe += len(X)
        return X, F, CV

    def initialize(self):
        X = self.problem.random(self.N, self.rng)
        self.X, self.F, self.CV = self.evaluate(X)
        self.scale = np.maximum(np.ptp(self.F, axis=0), 1e-12)

    def iterate(self):
        raise NotImplementedError

    def solution_set(self):
        if self.archive is not None and len(self.archive) > 0:
            return self.archive.X, self.archive.F, self.archive.CV
        return self.X, self.F, self.CV

    def result(self):
        X, F, CV = self.solution_set()
        m = non_dominated_mask(F, CV)
        feas = CV <= 0
        if feas.any():
            m &= feas
        X, F, CV = X[m], F[m], CV[m]
        _, u = np.unique(np.round(F, 10), axis=0, return_index=True)
        u = np.sort(u)
        return dict(X=X[u], F=F[u], CV=CV[u], feasible=bool(feas.any()), nfe=self.nfe)

    def _record(self):
        self.history.append((self.nfe, self.result()["F"].copy()))

    def run(self, budget, record=False, every=1):
        self.budget = budget
        t0 = time.time()
        try:
            self.initialize()
            if record:
                self._record()
            while True:
                self.iterate()
                self.gen += 1
                if record and self.gen % every == 0:
                    self._record()
        except BudgetExhausted:
            pass
        out = self.result()
        out["time"] = time.time() - t0
        out["history"] = self.history
        return out


def feasible_nd(X, F, CV):
    """Feasible non-dominated subset (or least-violating if none feasible)."""
    m = non_dominated_mask(F, CV)
    return X[m], F[m], CV[m]


# ----------------------------------------------------------------------------
# Selection / fitness helpers shared by several algorithms
# ----------------------------------------------------------------------------
def penalised(F, CV, scale, R=100.0):
    """Static penalty used by the older (pre-Deb) algorithms: F + R * CV * (initial objective range)."""
    return F + R * CV[:, None] * scale[None, :]


def nsga2_select(F, CV, N):
    """NSGA-II environmental selection: fill by fronts, truncate the last front by crowding distance.
    Returns (indices, rank, crowding) of the N survivors."""
    fronts, rank = fast_non_dominated_sort(F, CV)
    chosen, crowd = [], np.zeros(len(F))
    for fr in fronts:
        cd = crowding_distance(F[fr])
        crowd[fr] = cd
        if len(chosen) + len(fr) <= N:
            chosen += list(fr)
        else:
            need = N - len(chosen)
            order = np.argsort(-cd, kind="stable")
            chosen += list(fr[order[:need]])
            break
    chosen = np.array(chosen, int)
    return chosen, rank[chosen], crowd[chosen]


def sharing_counts(F, sigma, alpha=1.0, groups=None):
    """Niche counts m_i = sum_j sh(d_ij) with the triangular sharing function (objectives normalised)."""
    Fn = normalize(F)
    d = np.sqrt(((Fn[:, None, :] - Fn[None, :, :]) ** 2).sum(axis=2))
    sh = np.where(d < sigma, 1 - (d / sigma) ** alpha, 0.0)
    if groups is not None:
        sh = sh * (groups[:, None] == groups[None, :])
    return sh.sum(axis=1)


def tchebycheff(F, w, z, zn=None):
    """Weighted Tchebycheff value  max_j w_j |f_j - z_j| / (zn_j - z_j)  (rows of F)."""
    w = np.maximum(w, 1e-6)
    span = 1.0 if zn is None else np.where(zn - z > 1e-12, zn - z, 1.0)
    return np.max(w * np.abs(F - z) / span, axis=-1)


def grid_roulette(F, rng, n, ndiv=10, power=1.0):
    """n leader indices from an archive: roulette over grid cells with weight 1/count**power (sparse cells favoured),
    then a uniformly random member of the chosen cell."""
    cells = grid_cells(F, ndiv)
    uniq, inv, cnt = np.unique(cells, return_inverse=True, return_counts=True)
    p = (1.0 / cnt.astype(float) ** power)[inv] / cnt[inv]
    return rng.choice(len(F), n, p=p / p.sum())


def row_dominates(Fa, CVa, Fb, CVb):
    """Row-wise constrained dominance: a_i dominates b_i (Deb's rules)."""
    pareto = np.all(Fa <= Fb, axis=1) & np.any(Fa < Fb, axis=1)
    fa, fb = CVa <= 0, CVb <= 0
    return np.where(fa & fb, pareto, np.where(fa & ~fb, True, np.where(~fa & ~fb, CVa < CVb, False)))


def progress(alg):
    """Fraction of the evaluation budget already used (0..1)."""
    return min(1.0, alg.nfe / alg.budget) if np.isfinite(alg.budget) else min(1.0, alg.gen / 1000.0)
