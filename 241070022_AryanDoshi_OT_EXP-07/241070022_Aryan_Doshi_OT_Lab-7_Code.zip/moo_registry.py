"""
moo_registry.py -- catalogue of the 37 algorithms (number, name, family, module, class, test problems from Section 3)
and the experiment helpers (reference fronts, normalised metrics, repeated runs).
"""
import importlib
import time
import numpy as np
from moo_problems import get_problem
from moo_utils import hypervolume, igd, spacing, normalize, non_dominated_mask

CATALOGUE = [
    # id, module, class, kind, tests
    (1, "a01_weighted_sum", "WeightedSum", "classical", ["P1", "P3", "P4"]),
    (2, "a02_epsilon_constraint", "EpsilonConstraint", "classical", ["P2", "P2i", "P3", "P5"]),
    (3, "a03_benson", "Benson", "classical", ["P1", "P7"]),
    (4, "a04_weighted_metric", "WeightedMetric", "classical", ["P1", "P3"]),
    (5, "a05_value_function", "ValueFunction", "preference", ["P4", "P14"]),
    (6, "a06_goal_programming", "GoalProgramming", "preference", ["P11", "P7"]),
    (7, "a07_lexicographic", "Lexicographic", "preference", ["P11", "P7"]),
    (8, "a08_topsis", "TOPSIS", "ranking", ["P12", "P4"]),
    (9, "a09_vikor", "VIKOR", "ranking", ["P12", "P4"]),
    (10, "a10_vega", "VEGA", "ea", ["P2", "P2i", "P3"]),
    (11, "a11_moga", "MOGA", "ea", ["P3", "P5"]),
    (12, "a12_nsga", "NSGA", "ea", ["P5", "P7"]),
    (13, "a13_npga", "NPGA", "ea", ["P3", "P5"]),
    (14, "a14_nsga2", "NSGA2", "ea", ["P3", "P5", "P6"]),
    (15, "a15_nsga3", "NSGA3", "ea", ["P10_M3", "P10_M5"]),
    (16, "a16_spea2", "SPEA2", "ea", ["P4", "P5"]),
    (17, "a17_pesa2", "PESA2", "ea", ["P3", "P5"]),
    (18, "a18_moead", "MOEAD", "ea", ["P3", "P10_M3"]),
    (19, "a19_moead_de", "MOEADDE", "ea", ["P3", "P5"]),
    (20, "a20_moead_aco", "MOEADACO", "ea", ["P8"]),
    (21, "a21_constrained_nsga2", "ConstrainedNSGA2", "ea", ["P5", "P6", "P7"]),
    (22, "a22_mopso", "MOPSO", "ea", ["P4", "P5"]),
    (23, "a23_mogwo", "MOGWO", "ea", ["P5", "P9"]),
    (24, "a24_moabc", "MOABC", "ea", ["P3", "P6"]),
    (25, "a25_moaco", "MOACO", "ea", ["P8"]),
    (26, "a26_mosa", "MOSA", "ea", ["P3", "P5"]),
    (27, "a27_mode", "MODE", "ea", ["P3", "P5"]),
    (28, "a28_motlbo", "MOTLBO", "ea", ["P3", "P5"]),
    (29, "a29_moba", "MOBA", "ea", ["P3", "P4"]),
    (30, "a30_moma", "MOMA", "ea", ["P5", "P9"]),
    (31, "a31_rvea", "RVEA", "ea", ["P10_M3", "P10_M5"]),
    (32, "a32_ibea", "IBEA", "ea", ["P3", "P14"]),
    (33, "a33_smsemoa", "SMSEMOA", "ea", ["P3", "P14"]),
    (34, "a34_hype", "HypE", "ea", ["P10_M3", "P10_M5"]),
    (35, "a35_rnsga2", "RNSGA2", "ea", ["P5", "P14"]),
    (36, "a36_mgda", "MGDA", "gradient", ["P13a"]),
    (37, "a37_gradnorm", "GradNorm", "gradient", ["P13a"]),
]
INFO = {c[0]: dict(id=c[0], module=c[1], cls=c[2], kind=c[3], tests=c[4]) for c in CATALOGUE}


def module(i):
    return importlib.import_module("algos." + INFO[i]["module"])


def algo_class(i):
    return getattr(module(i), INFO[i]["cls"])


def algo_name(i):
    return algo_class(i).name


def make_algorithm(i, problem, seed=0, pop_size=None, **kw):
    cls = algo_class(i)
    if pop_size is None:
        pop_size = 100
        if i in (20, 25):
            pop_size = 50
        if i in (36, 37):
            pop_size = 20
        if problem.name.endswith("M5") and i in (10, 11, 12, 13, 14, 16, 17, 21, 22, 23, 24, 26, 27, 28, 29, 30, 32, 33, 34, 35):
            pop_size = 100
    return cls(problem, pop_size=pop_size, seed=seed, **kw)


# ----------------------------------------------------------------------------
# reference fronts and normalised metrics
# ----------------------------------------------------------------------------
_REF = {}


def set_reference(name, F):
    """Register a pooled 'best-known' front for problems without an analytic front (P8, P9)."""
    F = np.asarray(F, float)
    _REF[name] = F[non_dominated_mask(F)]


def reference_front(name):
    p = get_problem(name)
    if p.true_front is not None:
        return p.true_front
    return _REF.get(name)


def normalisation(name):
    R = reference_front(name)
    ideal, nadir = R.min(axis=0), R.max(axis=0)
    return ideal, np.where(nadir - ideal > 1e-12, nadir, ideal + 1.0)


def metrics(name, F, hv_samples=40000):
    """HV (ref point 1.1 in normalised space), IGD and spacing, all on normalised objectives."""
    ideal, nadir = normalisation(name)
    R = normalize(reference_front(name), ideal, nadir)
    if len(F) == 0:
        return dict(HV=0.0, IGD=np.inf, Spacing=np.nan, n=0)
    Fn = normalize(F, ideal, nadir)
    M = Fn.shape[1]
    return dict(HV=hypervolume(Fn, np.full(M, 1.1), hv_samples), IGD=igd(Fn, R), Spacing=spacing(Fn), n=len(F))


def hv_reference_value(name, hv_samples=40000):
    ideal, nadir = normalisation(name)
    R = normalize(reference_front(name), ideal, nadir)
    return hypervolume(R, np.full(R.shape[1], 1.1), hv_samples)


def run_once(i, name, seed, budget, **kw):
    p = get_problem(name)
    alg = make_algorithm(i, p, seed=seed, **kw)
    t = time.time()
    r = alg.run(budget)
    r["time"] = time.time() - t
    r["alg"] = alg
    return r


def run_repeated(i, name, budget, seeds, **kw):
    rows, fronts = [], []
    for s in seeds:
        r = run_once(i, name, s, budget, **kw)
        m = metrics(name, r["F"])
        m.update(seed=s, time=r["time"], nfe=r["nfe"], feasible=r["feasible"])
        rows.append(m)
        fronts.append(r["F"])
    return rows, fronts
