# OT Lab Experiment 7 — Multiobjective Optimization: 37 Algorithms, Trade-offs and Applications

**Student:** Aryan Doshi  
**Roll number:** 241070022  
**Programme:** Third-Year B.Tech, Computer Engineering  
**Institute:** Veermata Jijabai Technological Institute (VJTI), Mumbai  
**Experiment:** 7 — Multiobjective Optimization: 37 Algorithms, Trade-offs and Applications

---

## 1. Overview

This source package implements a collection of 37 multiobjective optimization and multi-criteria decision-making methods, together with shared benchmark-problem definitions, Pareto and performance-metric utilities, algorithm registration, and repeated-run experiment helpers. It is intended to be used with the accompanying Experiment 7 Jupyter notebook and the separately submitted raw-results archive.

The package includes the allocated Task C algorithms for roll number **22**:

| Assigned slot | Algorithm number | Method |
|---|---:|---|
| Algorithm 1 | 22 | MOPSO — Multi-Objective Particle Swarm Optimization |
| Algorithm 2 | 34 | HypE — Hypervolume Estimation Algorithm |
| Algorithm 3 | 9 | VIKOR — Multi-Criteria Compromise Ranking Method |

The report and results should be interpreted alongside the assignment specification and the notebook used to run the experiments. A successful import or unit test is a sanity check, not by itself proof that every implementation is identical to every canonical published variant.

## 2. Package contents

Run commands from the extracted directory that contains `moo_utils.py`, `moo_registry.py`, and this README.

- `moo_utils.py` — shared multiobjective utilities, including Pareto-dominance checks, constrained dominance, non-dominated sorting, crowding distance, normalization, reference-point helpers, performance metrics, and utility sanity tests.
- `moo_problems.py` — benchmark/problem definitions and problem factory.
- `moo_base.py` — common algorithm base classes and infrastructure.
- `moo_registry.py` — catalogue and factory for the 37 algorithms, plus reference-front and metric helpers.
- `moo_experiments.py` — repeated-run helpers, result caching, CSV output, summary calculations, and plotting helpers.
- `moo_text.py` — explanatory text and metadata used by the notebook.
- `algos/` — algorithm-specific implementations (`a01_...py` through `a37_...py`) and shared family modules.

The code ZIP contains the Python source package. The Jupyter notebook and raw-results archive are separate deliverables; keep them together with the report when preparing the full submission, as required by the assignment.

## 3. Requirements

- Python 3.10 or newer recommended.
- `numpy`
- `pandas`
- `matplotlib`
- `scikit-learn`
- `scipy`

Install the dependencies from a terminal in the extracted directory:

```bash
python -m pip install numpy pandas matplotlib scikit-learn scipy
```

If `python` does not refer to the intended Python installation on Windows, use `py -m pip ...` instead. A virtual environment is recommended to avoid conflicts with other Python projects.

**Optimization-library note:** The classical methods in algorithms 1–7 use `scipy.optimize.minimize` for their single-objective scalar subproblem. The assignment specification allows `scipy.optimize` for a single-objective or LP subproblem; the multiobjective framework, algorithm bookkeeping, Pareto utilities, and performance-metric utilities are implemented in the supplied source. Do not substitute an external multiobjective optimization framework for the implementations in this package.

## 4. Running the code

### 4.1 Check the Python environment

```bash
python --version
python -m pip show numpy pandas matplotlib scikit-learn scipy
```

### 4.2 Run shared utility sanity tests

```bash
python -c "import moo_utils; print(moo_utils.run_unit_tests())"
```

### 4.3 Run benchmark-problem sanity checks

```bash
python -c "import moo_problems; print(moo_problems.sanity_checks())"
```

### 4.4 Inspect the 37 registered algorithms

```bash
python -c "import moo_registry as R; [print(i, R.algo_name(i), R.INFO[i]['module']) for i in range(1, 38)]"
```

### 4.5 Run an algorithm smoke test

The following example constructs Algorithm 22 (MOPSO) for problem P3, uses random seed 0, and runs a small evaluation budget. It is a quick execution check, not a replacement for the experiment budgets used in the report.

```python
from moo_registry import make_algorithm
from moo_problems import get_problem

problem = get_problem("P3")
algorithm = make_algorithm(22, problem, seed=0)
result = algorithm.run(200)
print("Algorithm:", algorithm.name)
print("Objective array shape:", result["F"].shape)
print("Evaluations:", result["nfe"])
```

Save the example as a Python file or run it in a Python interpreter from the package directory. The package is designed to be imported by the accompanying notebook; use that notebook to reproduce the complete experiment workflow and report figures/tables.

### 4.6 Reproduce notebook experiments

1. Extract the code ZIP into a working directory.
2. Place/open the submitted Experiment 7 `.ipynb` notebook in the same working directory, so it can import the Python modules.
3. Install the dependencies listed above in the notebook's active Python environment.
4. Start Jupyter Lab/Notebook and open the notebook.
5. Run the notebook cells in order, following any task-specific instructions and parameters in the notebook and assignment sheet.
6. Confirm that output tables and plots are generated and inspect any exceptions or warnings.
7. Keep the generated CSV/NPZ files and figures that support the final report. The existing raw-results archive is a separate submission item and should not be assumed to have been regenerated merely by opening the notebook.

For example, install Jupyter if it is not already available:

```bash
python -m pip install jupyter
python -m jupyter lab
```

## 5. Experiment configuration and random seeds

The default configuration declared in `moo_experiments.py` is:

```python
CFG = dict(
    BUDGET=10000,
    SEEDS=list(range(10)),
    RESULTS="results",
    FIGS="figures",
    P9_BUDGET=3000,
)
```

This corresponds to an objective-evaluation budget of 10,000 for standard problems, seeds **0 through 9**, and a P9 budget of 3,000. The helper's quick/debug configuration uses a budget of 2,000, seeds **0, 1, 2**, and a P9 budget of 600. Quick/debug results should not be presented as results from the full configuration.

Some reference-front construction routines use additional seeds, including **101** and **102**, as specified in the experiment helper. Task-specific notebook cells may also specify their own parameters, budgets, or seeds; when reproducing a particular table or figure, follow the corresponding notebook cell and preserve its exact settings. If settings are changed, record the changes and do not label the resulting data as an exact reproduction of the original configuration.

## 6. Output files and reproducibility

The experiment helper uses these output directories relative to the current working directory:

- `results/` — cached run data (`.npz`), objective-vector CSV files, reference fronts, and summary tables when generated.
- `figures/` — generated plots when the corresponding notebook/experiment routines are run.

The helper can reuse cached `.npz` runs if a matching cache file already exists. Therefore, rerunning a notebook may reuse earlier results instead of recomputing them. If a complete fresh rerun is specifically required, first back up the results directory and then remove or move the relevant cache files deliberately; be aware that this may require substantial computation time.

The separate raw-results ZIP is intended to preserve the result files behind the report's tables and plots. Keep file names and directory structure intact where possible, and check that every report table and figure can be traced to its underlying result data.

## 7. Performance metrics and interpretation

The shared registry/utilities provide multiobjective performance metrics and reference-front helpers. In interpreting the outputs:

- **Hypervolume (HV):** larger is generally better for a fixed, valid reference point and consistent objective normalization.
- **Inverted Generational Distance (IGD):** smaller is better; interpretation depends on the reference front used.
- **Spacing:** smaller generally indicates more uniform nearest-neighbour spacing among obtained solutions, but should be considered together with convergence and coverage metrics.
- **Feasibility:** constrained problems should be interpreted with feasibility information, not objective metrics alone.
- **Runtime and stochastic variation:** these depend on the environment, parameters, evaluation budget, and random seed.

The code computes hypervolume exactly in two dimensions and uses a Monte Carlo estimate for three or more dimensions. For problems without an analytic reference front, the experiment helper may construct a best-known reference front from pooled runs of selected algorithms. These implementation choices affect metric interpretation and should be disclosed when discussing results.

**End of README — OT Lab Experiment 7**
