"""
moo_problems.py -- the 14 problem statements of Section 4 as Python functions.
Every problem returns objective values (all MINIMISED) and a constraint violation
(CV = sum of max(0, g_k), g_k <= 0 means feasible).  Max f is converted to Min -f;
Problem.signs lets you print the values in their natural direction again.
"""
import numpy as np
from moo_utils import das_dennis, non_dominated_mask


class Problem:
    def __init__(self, name, n_var, n_obj, lb, ub, fun, gfun=None, vtype="real",
                 signs=None, labels=None, data=None, front_fn=None, desc=""):
        self.name, self.n_var, self.n_obj, self.vtype = name, n_var, n_obj, vtype
        self.lb = np.broadcast_to(np.asarray(lb, float), (n_var,)).copy()
        self.ub = np.broadcast_to(np.asarray(ub, float), (n_var,)).copy()
        self.fun, self.gfun = fun, gfun
        self.signs = np.ones(n_obj) if signs is None else np.asarray(signs, float)
        self.labels = labels or ["f%d" % (i + 1) for i in range(n_obj)]
        self.data = data or {}
        self.front_fn = front_fn
        self.desc = desc
        self._front = None

    # ---- encoding -------------------------------------------------------
    def repair(self, X):
        X = np.atleast_2d(X)
        if self.vtype == "perm":
            return X.astype(int)
        X = np.clip(X, self.lb, self.ub)
        if self.vtype == "int":
            X = np.rint(X)
        elif self.vtype == "binary":
            X = (X >= 0.5).astype(float)
        elif self.vtype == "simplex":
            s = X.sum(axis=1, keepdims=True)
            X = np.where(s > 1e-12, X / np.where(s > 1e-12, s, 1), 1.0 / self.n_var)
        return X

    def random(self, N, rng):
        if self.vtype == "perm":
            return np.array([rng.permutation(self.n_var) for _ in range(N)])
        return self.lb + rng.random((N, self.n_var)) * (self.ub - self.lb)

    # ---- evaluation -----------------------------------------------------
    def evaluate(self, X):
        """Returns F (N, m) and CV (N,) for already repaired X."""
        X = np.atleast_2d(X)
        F = np.asarray(self.fun(X), float)
        if self.gfun is None:
            return F, np.zeros(len(X))
        G = np.asarray(self.gfun(X), float)
        CV = np.maximum(G, 0).sum(axis=1)
        return F, np.where(CV < 1e-7, 0.0, CV)          # numerical tolerance for solutions on a boundary

    def f1(self, x):
        return self.fun(np.atleast_2d(x))[0]

    def g1(self, x):
        return np.atleast_1d(self.gfun(np.atleast_2d(x))[0]) if self.gfun is not None else np.zeros(0)

    def original(self, F):
        """Objective values in their natural direction (undo Max f = Min -f)."""
        return np.asarray(F) * self.signs

    @property
    def true_front(self):
        if self._front is None and self.front_fn is not None:
            self._front = np.asarray(self.front_fn(), float)
        return self._front


# ----------------------------------------------------------------------------
# P1  Factory production speed (convex, 1 variable)
# ----------------------------------------------------------------------------
def P1():
    f = lambda X: np.column_stack([(X[:, 0] - 3) ** 2, (X[:, 0] - 7) ** 2])
    fr = lambda: (lambda x: np.column_stack([(x - 3) ** 2, (x - 7) ** 2]))(np.linspace(3, 7, 400))
    return Problem("P1", 1, 2, 1, 10, f, front_fn=fr, labels=["cost", "quality loss"],
                   desc="Factory production speed (convex, 1 var)")


# ----------------------------------------------------------------------------
# P2  Delivery fleet sizing (real or integer)
# ----------------------------------------------------------------------------
def P2(integer=False):
    f = lambda X: np.column_stack([100.0 / X[:, 0], X[:, 0] ** 2])
    xs = (lambda: np.arange(1, 11, dtype=float)) if integer else (lambda: np.linspace(1, 10, 400))
    fr = lambda: f(xs()[:, None])
    return Problem("P2i" if integer else "P2", 1, 2, 1, 10, f, vtype="int" if integer else "real",
                   front_fn=fr, labels=["delivery cost", "delay penalty"],
                   desc="Delivery fleet sizing (%s)" % ("integer" if integer else "real"))


# ----------------------------------------------------------------------------
# P3  ZDT2, n = 10 (non-convex)
# ----------------------------------------------------------------------------
def P3(n=10):
    def f(X):
        g = 1 + 9 * X[:, 1:].sum(axis=1) / (n - 1)
        return np.column_stack([X[:, 0], g * (1 - (X[:, 0] / g) ** 2)])
    fr = lambda: np.column_stack([np.linspace(0, 1, 500), 1 - np.linspace(0, 1, 500) ** 2])
    return Problem("P3", n, 2, 0, 1, f, front_fn=fr, desc="ZDT2 non-convex benchmark, n=10")


# ----------------------------------------------------------------------------
# P4  Investment portfolio (equality constraint by normalisation)
# ----------------------------------------------------------------------------
MU4 = np.array([0.08, 0.12, 0.15, 0.10])
SIG4 = np.array([[0.010, 0.002, 0.001, 0.003],
                 [0.002, 0.040, 0.006, 0.004],
                 [0.001, 0.006, 0.090, 0.005],
                 [0.003, 0.004, 0.005, 0.020]])


def P4():
    def f(X):
        W = X / np.where(X.sum(axis=1, keepdims=True) > 1e-12, X.sum(axis=1, keepdims=True), 1.0)
        risk = np.einsum("ni,ij,nj->n", W, SIG4, W)
        return np.column_stack([risk, -(W @ MU4)])

    def fr():
        from scipy.optimize import minimize
        pts = []
        w0 = np.ones(4) / 4
        for r in np.linspace(MU4.min(), MU4.max(), 150):
            res = minimize(lambda w: w @ SIG4 @ w, w0, method="SLSQP", bounds=[(0, 1)] * 4,
                           constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1},
                                        {"type": "ineq", "fun": lambda w, r=r: w @ MU4 - r}],
                           options={"ftol": 1e-12, "maxiter": 300})
            if res.success:
                pts.append([res.x @ SIG4 @ res.x, -(res.x @ MU4)])
        pts = np.array(pts)
        return pts[non_dominated_mask(pts)]
    return Problem("P4", 4, 2, 0, 1, f, vtype="simplex", front_fn=fr, labels=["risk", "return"],
                   signs=[1, -1], desc="Investment portfolio, sum(w)=1 by normalisation")


# ----------------------------------------------------------------------------
# P5  Cantilever beam (constrained)
# ----------------------------------------------------------------------------
L5, P5LOAD, E5 = 1.0, 1000.0, 200e9


def P5():
    def f(X):
        b, h = X[:, 0], X[:, 1]
        return np.column_stack([7850.0 * L5 * b * h, 4 * P5LOAD * L5 ** 3 / (E5 * b * h ** 3)])

    def g(X):
        b, h = X[:, 0], X[:, 1]
        return (6 * P5LOAD * L5 / (b * h ** 2) / 250e6 - 1)[:, None]   # stress <= 250 MPa

    def fr():
        # for a given mass m the stiffest design uses the largest feasible h
        ms = np.geomspace(3.847, 157.0, 600)
        h = np.minimum(0.20, ms / 78.5)
        b = ms / (7850.0 * h)
        X = np.column_stack([b, h])
        ok = (g(X)[:, 0] <= 1e-9) & (b >= 0.01 - 1e-12) & (b <= 0.10 + 1e-12)
        return f(X[ok])
    return Problem("P5", 2, 2, [0.01, 0.02], [0.10, 0.20], f, g, front_fn=fr,
                   labels=["mass [kg]", "deflection [m]"], desc="Cantilever beam, stress constraint")


# ----------------------------------------------------------------------------
# P6  Binh-Korn (hard constraints)
# ----------------------------------------------------------------------------
def P6():
    def f(X):
        x1, x2 = X[:, 0], X[:, 1]
        return np.column_stack([4 * x1 ** 2 + 4 * x2 ** 2, (x1 - 5) ** 2 + (x2 - 5) ** 2])

    def g(X):
        x1, x2 = X[:, 0], X[:, 1]
        return np.column_stack([((x1 - 5) ** 2 + x2 ** 2) / 25 - 1, 1 - ((x1 - 8) ** 2 + (x2 + 3) ** 2) / 7.7])

    def fr():
        t = np.linspace(0, 3, 300)
        X1 = np.column_stack([t, t])
        s = np.linspace(3, 5, 200)
        X2 = np.column_stack([s, np.full_like(s, 3.0)])
        return f(np.vstack([X1, X2]))
    return Problem("P6", 2, 2, [0, 0], [5, 3], f, g, front_fn=fr, desc="Binh-Korn constrained benchmark")


# ----------------------------------------------------------------------------
# P7  Water allocation (linear trade-off)
# ----------------------------------------------------------------------------
def P7():
    f = lambda X: np.column_stack([-0.8 * X[:, 0], -1.2 * X[:, 1]])
    g = lambda X: ((X[:, 0] + X[:, 1] - 90.0) / 90.0)[:, None]

    def fr():
        x1 = np.linspace(10, 70, 300)
        return f(np.column_stack([x1, 90 - x1]))
    return Problem("P7", 2, 2, [10, 20], [70, 80], f, g, front_fn=fr, signs=[-1, -1],
                   labels=["agri yield", "industrial output"], desc="Water allocation with environmental flow")


# ----------------------------------------------------------------------------
# P8  Bi-objective TSP, 15 customers + depot (permutation)
# ----------------------------------------------------------------------------
def P8():
    np.random.seed(7)                                   # seed 7 as required
    coords = np.random.uniform(0, 100, (16, 2))         # row 0 = depot
    U = np.random.uniform(0.5, 2.0, (16, 16))
    U = np.triu(U, 1)
    U = U + U.T                                         # symmetric traffic factor
    D = np.sqrt(((coords[:, None, :] - coords[None, :, :]) ** 2).sum(axis=2))
    T = D * U

    def f(X):
        tours = np.hstack([np.zeros((len(X), 1), int), X + 1, np.zeros((len(X), 1), int)])
        a, b = tours[:, :-1], tours[:, 1:]
        return np.column_stack([D[a, b].sum(axis=1), T[a, b].sum(axis=1)])
    return Problem("P8", 15, 2, 0, 14, f, vtype="perm", data=dict(coords=coords, D=D, T=T, U=U),
                   labels=["distance", "time"], desc="Bi-objective TSP (distance, time), 15 customers")


# ----------------------------------------------------------------------------
# P9  Feature selection, Wisconsin breast cancer (binary), own 5-NN + 5-fold CV
# ----------------------------------------------------------------------------
def P9():
    from sklearn.datasets import load_breast_cancer      # only used to LOAD the data
    data = load_breast_cancer()
    Z = data.data.astype(float)
    Z = (Z - Z.mean(axis=0)) / Z.std(axis=0)             # z-score (coded by us)
    y = data.target.astype(int)
    n, d = Z.shape
    diff2 = ((Z[:, None, :] - Z[None, :, :]) ** 2).astype(np.float32).reshape(n * n, d)
    rng = np.random.default_rng(0)
    perm = rng.permutation(n)
    folds = np.array_split(perm, 5)                      # fixed 5 folds
    splits = []
    for k in range(5):
        te = folds[k]
        tr = np.concatenate([folds[j] for j in range(5) if j != k])
        splits.append((te, tr))
    cache = {}

    def cv_error(mask):
        key = mask.tobytes()
        if key in cache:
            return cache[key]
        if mask.sum() == 0:
            return 1.0
        dist = (diff2 @ mask.astype(np.float32)).reshape(n, n)
        wrong = 0
        for te, tr in splits:
            sub = dist[np.ix_(te, tr)]
            idx = np.argpartition(sub, 5, axis=1)[:, :5]
            pred = (y[tr][idx].sum(axis=1) >= 3).astype(int)    # 5-NN majority vote
            wrong += int((pred != y[te]).sum())
        cache[key] = wrong / n
        return cache[key]

    def f(X):
        return np.array([[cv_error(x), x.sum()] for x in X])

    g = lambda X: (1.0 - X.sum(axis=1))[:, None]           # at least one feature
    return Problem("P9", d, 2, 0, 1, f, g, vtype="binary", labels=["CV error", "#features"],
                   data=dict(cv_error=cv_error, names=data.feature_names),
                   desc="Feature selection, 5-NN + 5-fold CV (own code)")


# ----------------------------------------------------------------------------
# P10  DTLZ2, M = 3 or 5 (many-objective)
# ----------------------------------------------------------------------------
def P10(M=3):
    n = M + 9

    def f(X):
        g = ((X[:, M - 1:] - 0.5) ** 2).sum(axis=1)
        F = np.empty((len(X), M))
        for m in range(M):
            val = (1 + g)
            for i in range(M - m - 1):
                val = val * np.cos(X[:, i] * np.pi / 2)
            if m > 0:
                val = val * np.sin(X[:, M - m - 1] * np.pi / 2)
            F[:, m] = val
        return F[:, ::-1] if False else F

    # DTLZ2 definition: f_1 = (1+g) prod cos ; f_M = (1+g) sin(x1 pi/2)
    def f_dtlz(X):
        g = ((X[:, M - 1:] - 0.5) ** 2).sum(axis=1)
        F = np.empty((len(X), M))
        for m in range(M):                       # m = 0 .. M-1  <->  f_{m+1}
            val = 1 + g
            for i in range(M - 1 - m):
                val = val * np.cos(X[:, i] * np.pi / 2)
            if m > 0:
                val = val * np.sin(X[:, M - 1 - m] * np.pi / 2)
            F[:, m] = val
        return F

    def fr():
        p = 30 if M == 3 else 6
        W = das_dennis(M, p)
        return W / np.linalg.norm(W, axis=1, keepdims=True)
    return Problem("P10_M%d" % M, n, M, 0, 1, f_dtlz, front_fn=fr, desc="DTLZ2, M=%d" % M)


# ----------------------------------------------------------------------------
# P11  Production planning (goals and priorities)
# ----------------------------------------------------------------------------
def P11():
    f = lambda X: np.column_stack([-(4 * X[:, 0] + 6 * X[:, 1]), -(X[:, 0] + X[:, 1])])
    g = lambda X: np.column_stack([(2 * X[:, 0] + 3 * X[:, 1] - 1200) / 1200, (4 * X[:, 0] + 2 * X[:, 1] - 1600) / 1600])

    def fr():
        # (300,200) gives the maximum profit AND the maximum units: it dominates everything -> single Pareto point
        return f(np.array([[300.0, 200.0]]))
    return Problem("P11", 2, 2, [0, 0], [400, 400], f, g, front_fn=fr, signs=[-1, -1],
                   labels=["profit", "units"], desc="Production planning (goal/lexicographic)")


# ----------------------------------------------------------------------------
# P12  Supplier selection (MCDM ranking data)
# ----------------------------------------------------------------------------
P12_NAMES = ["S1", "S2", "S3", "S4", "S5"]
P12_CRITERIA = ["Cost $k (min)", "Quality /10 (max)", "Delivery days (min)", "Reliability % (max)"]
P12_DATA = np.array([[120, 7, 10, 92],
                     [100, 7, 14, 88],
                     [140, 9, 7, 95],
                     [90, 6, 18, 80],
                     [130, 8, 9, 90]], float)
P12_SENSE = np.array([-1, +1, -1, +1])        # -1 = minimise, +1 = maximise
P12_WEIGHTS = np.array([0.3, 0.3, 0.2, 0.2])


def P12_minimisation_matrix():
    return P12_DATA * (-P12_SENSE)             # all columns "smaller is better"


# ----------------------------------------------------------------------------
# P13  Multi-task learning
# ----------------------------------------------------------------------------
A13, B13 = np.array([3.0, 3.0]), np.array([-3.0, -3.0])


def P13a():
    f = lambda X: np.column_stack([((X - A13) ** 2).sum(axis=1), ((X - B13) ** 2).sum(axis=1)])
    jac = lambda x: np.vstack([2 * (x - A13), 2 * (x - B13)])        # (2 tasks, 2 vars)

    def fr():
        t = np.linspace(0, 1, 300)
        X = A13 + t[:, None] * (B13 - A13)
        return f(X)
    return Problem("P13a", 2, 2, -6, 6, f, front_fn=fr, data=dict(jac=jac, start=np.array([0.5, 5.0])),
                   desc="Two quadratic tasks, Pareto set = segment a-b")


# ----------------------------------------------------------------------------
# P14  Laptop design with a decision-maker preference
# ----------------------------------------------------------------------------
def P14():
    # NOTE: the sanity values of the sheet ((13,40) -> 1.53 kg, ~9.0 h and (13,90) -> 2.13 kg,
    # ~20.2 h) are reproduced by a runtime of  x2 / (5*(0.5 + 0.03*x1)) = x2/(2.5+0.15*x1).
    def f(X):
        x1, x2 = X[:, 0], X[:, 1]
        return np.column_stack([0.4 + 0.05 * x1 + 0.012 * x2, -(x2 / (5 * (0.5 + 0.03 * x1)))])

    def fr():
        x2 = np.linspace(40, 90, 300)
        return f(np.column_stack([np.full_like(x2, 13.0), x2]))
    return Problem("P14", 2, 2, [13, 40], [17, 90], f, front_fn=fr, signs=[1, -1],
                   labels=["weight [kg]", "runtime [h]"], desc="Laptop design with reference point (1.8 kg, 12 h)")


# ----------------------------------------------------------------------------
BUILDERS = {"P1": P1, "P2": P2, "P2i": lambda: P2(True), "P3": P3, "P4": P4, "P5": P5, "P6": P6,
            "P7": P7, "P8": P8, "P9": P9, "P10_M3": lambda: P10(3), "P10_M5": lambda: P10(5),
            "P11": P11, "P13a": P13a, "P14": P14}
_CACHE = {}


def get_problem(name):
    """Return a (cached) Problem instance by name, e.g. get_problem('P3')."""
    if name not in _CACHE:
        _CACHE[name] = BUILDERS[name]()
    return _CACHE[name]


def sanity_checks(verbose=True):
    """Hand-checkable sanity values given in Section 4 of the assignment sheet."""
    ok = lambda a, b, tol=1e-6: np.allclose(a, b, atol=tol, rtol=1e-3)
    res = {}
    p = get_problem("P1"); res["P1 x=5"] = ok(p.f1([5]), [4, 4]); res["P1 x=3"] = ok(p.f1([3]), [0, 16])
    p = get_problem("P2"); res["P2 x=2"] = ok(p.f1([2]), [50, 4]); res["P2 x=10"] = ok(p.f1([10]), [10, 100])
    p = get_problem("P3")
    x = np.zeros(10); x[0] = 0.5; res["P3 front point"] = ok(p.f1(x), [0.5, 0.75])
    p = get_problem("P4"); res["P4 w=(0,0,1,0)"] = ok(p.original(p.f1([0, 0, 1, 0])), [0.09, 0.15])
    p = get_problem("P5"); F, CV = p.evaluate(np.array([[0.01, 0.05]]))
    res["P5 (0.01,0.05)"] = ok(F[0], [3.925, 0.016]) and CV[0] == 0
    p = get_problem("P6")
    F, CV = p.evaluate(np.array([[0, 0], [5, 3]]))
    res["P6 points"] = ok(F, [[0, 50], [136, 4]]) and (CV == 0).all()
    p = get_problem("P7"); res["P7 ends"] = ok(p.original(p.f1([10, 80])), [8, 96]) and ok(p.original(p.f1([70, 20])), [56, 24])
    p = get_problem("P11")
    res["P11 corners"] = ok(p.original(p.f1([300, 200])), [2400, 500]) and ok(p.original(p.f1([0, 400])), [2400, 400])
    p = get_problem("P14")
    res["P14 (13,40)"] = ok(p.original(p.f1([13, 40])), [1.53, 8.99], 0.02)
    res["P14 (13,90)"] = ok(p.original(p.f1([13, 90])), [2.13, 20.2], 0.05)
    p = get_problem("P10_M3"); x = np.full(12, 0.5); x[0] = 0.0
    res["P10 on sphere"] = abs((p.f1(x) ** 2).sum() - 1) < 1e-9
    if verbose:
        for k, v in res.items():
            print(("PASS " if v else "FAIL ") + k)
    assert all(res.values()), "a sanity check failed"
    return res


if __name__ == "__main__":
    sanity_checks()
