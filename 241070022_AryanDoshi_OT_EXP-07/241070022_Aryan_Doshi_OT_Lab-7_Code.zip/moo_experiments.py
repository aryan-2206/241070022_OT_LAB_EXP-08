"""
moo_experiments.py -- experiment helpers: cached runs (raw result files), reference fronts, repeated runs,
summary tables and plotting.  Everything here only calls our own algorithms and metrics.
"""
import os
import time
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from moo_registry import (INFO, algo_name, make_algorithm, metrics, reference_front, set_reference,
                          hv_reference_value, normalisation)
from moo_problems import get_problem
from moo_utils import normalize, non_dominated_mask

CFG = dict(BUDGET=10000, SEEDS=list(range(10)), RESULTS="results", FIGS="figures", P9_BUDGET=3000)
os.makedirs(CFG["RESULTS"], exist_ok=True)
os.makedirs(CFG["FIGS"], exist_ok=True)


def configure(quick=False):
    if quick:
        CFG.update(BUDGET=2000, SEEDS=[0, 1, 2], P9_BUDGET=600)
    return CFG


def _tag(kw):
    import hashlib
    out = ""
    for k, v in sorted(kw.items()):
        sv = str(v).replace(" ", "")
        if not (np.isscalar(v) or isinstance(v, str)) or len(sv) > 24:
            sv = hashlib.md5(sv.encode()).hexdigest()[:8]          # dicts / lists -> short hash
        out += "_%s%s" % (k, sv)
    return out


def cached_run(i, pname, seed, budget, **kw):
    """One run of algorithm i on problem pname. The obtained front is stored as a raw result file."""
    base = "%s/raw_%02d_%s_b%d_s%d%s" % (CFG["RESULTS"], i, pname, budget, seed, _tag(kw))
    if os.path.exists(base + ".npz"):
        z = np.load(base + ".npz", allow_pickle=True)
        return dict(F=z["F"], X=z["X"], time=float(z["time"]), nfe=int(z["nfe"]), feasible=bool(z["feasible"]))
    p = get_problem(pname)
    alg = make_algorithm(i, p, seed=seed, **kw)
    t = time.time()
    r = alg.run(budget)
    r["time"] = time.time() - t
    np.savez(base + ".npz", F=r["F"], X=r["X"], time=r["time"], nfe=r["nfe"], feasible=r["feasible"])
    np.savetxt(base + ".csv", p.original(r["F"]), delimiter=",", header=",".join(p.labels), comments="")
    return dict(F=r["F"], X=r["X"], time=r["time"], nfe=r["nfe"], feasible=r["feasible"])


def ensure_references():
    """Best-known fronts for problems without an analytic front (P8 and P9): pooled non-dominated union of
    long runs of several of our own algorithms (never from an external library)."""
    for pname, algs, budget, seeds in (("P8", (14, 30, 20, 25), 20000 if CFG["BUDGET"] >= 10000 else 4000, (101, 102)),
                                       ("P9", (14, 30, 23), 2 * CFG["P9_BUDGET"], (101,))):
        path = "%s/reference_%s.csv" % (CFG["RESULTS"], pname)
        if os.path.exists(path):
            set_reference(pname, np.loadtxt(path, delimiter=",", skiprows=1))
            continue
        pool = [cached_run(i, pname, s, budget)["F"] for i in algs for s in seeds]
        F = np.vstack(pool)
        set_reference(pname, F)
        np.savetxt(path, reference_front(pname), delimiter=",", header="f1,f2", comments="")


def budget_for(pname):
    return CFG["P9_BUDGET"] if pname == "P9" else CFG["BUDGET"]


def bench(i, pname, budget=None, seeds=None, **kw):
    """Repeated runs -> DataFrame with one row per seed (HV, IGD, Spacing, n, time)."""
    budget = budget or budget_for(pname)
    seeds = CFG["SEEDS"] if seeds is None else seeds
    rows, fronts = [], []
    for s in seeds:
        r = cached_run(i, pname, s, budget, **kw)
        m = metrics(pname, r["F"])
        m.update(alg=i, name=algo_name(i), problem=pname, seed=s, time=r["time"], nfe=r["nfe"], feasible=r["feasible"])
        rows.append(m)
        fronts.append(r["F"])
    return pd.DataFrame(rows), fronts


def summarise(df):
    g = df.groupby(["alg", "name", "problem"])
    out = g.agg(HV_mean=("HV", "mean"), HV_std=("HV", "std"), Spacing_mean=("Spacing", "mean"), Spacing_std=("Spacing", "std"),
                IGD_mean=("IGD", "mean"), IGD_std=("IGD", "std"), n_pts=("n", "mean"), time_s=("time", "mean"),
                feasible=("feasible", "mean")).reset_index()
    return out


def fmt_pm(m, s, d=3):
    return ("%." + str(d) + "f ± %." + str(d) + "f") % (m, 0.0 if np.isnan(s) else s)


# ----------------------------------------------------------------------------
# plotting
# ----------------------------------------------------------------------------
def plot_front(ax, pname, F, label="obtained", color="tab:red", ref=True, s=14):
    p = get_problem(pname)
    R = reference_front(pname)
    O = p.original(F)
    if p.n_obj == 2:
        if ref and R is not None:
            Ro = p.original(R)
            o = np.argsort(Ro[:, 0])
            ax.plot(Ro[o, 0], Ro[o, 1], "-", color="0.55", lw=1.5, label="true / best-known front") if len(Ro) > 1 else \
                ax.plot(Ro[:, 0], Ro[:, 1], "k*", ms=10, label="true / best-known front")
        ax.scatter(O[:, 0], O[:, 1], s=s, color=color, label=label, zorder=3)
        ax.set_xlabel(p.labels[0])
        ax.set_ylabel(p.labels[1])
    return ax


def plot_front_3d(fig, pos, pname, F, title=""):
    ax = fig.add_subplot(*pos, projection="3d")
    R = reference_front(pname)
    ax.scatter(R[:, 0], R[:, 1], R[:, 2], s=2, color="0.75")
    ax.scatter(F[:, 0], F[:, 1], F[:, 2], s=8, color="tab:red")
    ax.set_title(title, fontsize=9)
    return ax


def parallel_coordinates(ax, F, color="tab:blue", alpha=0.4):
    for f in F:
        ax.plot(range(1, len(f) + 1), f, color=color, alpha=alpha, lw=0.8)
    ax.set_xlabel("objective")
    ax.set_xticks(range(1, F.shape[1] + 1))


def save_fig(fig, name):
    path = "%s/%s.png" % (CFG["FIGS"], name)
    fig.savefig(path, dpi=110, bbox_inches="tight")
    return path
